﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDAL.Models;
namespace EmployeeDAL.EmployeeDataAccess
{
    public interface IEmployeeDataProvider
    {
        Task<Employee> GetEmployeeById(int EmployeeID);

        Task<IEnumerable<Employee>> GetEmployees();

        Task UpdateEmployee(Employee employee);

        Task TermianteEmployee(int EmployeeID);

        Task InsertEmployee(Employee employee);

    }
}
