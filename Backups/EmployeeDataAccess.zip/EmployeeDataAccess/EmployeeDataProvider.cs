﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDAL.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Dapper;
using System.Data;

namespace EmployeeDAL.EmployeeDataAccess
{
    public class EmployeeDataProvider
    {
        private readonly string connectionstring = "Server=(localdb)\\mssqllocaldb;Database=Testing;Trusted_Connection=True;";
        private readonly TestingContext testingContext;
        private SqlConnection sqlConnection;
      

        public async Task<Employee> GetEmployeeById(int EmployeeID)
        {
            using (var sqlConnection = new SqlConnection(connectionstring))
            {
                await sqlConnection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@EmployeeID", EmployeeID);


                return await sqlConnection.QuerySingleOrDefaultAsync<Employee>(
                    "GetEmployee",
                    parameters,
                    commandType: CommandType.StoredProcedure);
            }
        }


        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            using (var sqlConnection = new SqlConnection(connectionstring))
            {
                await sqlConnection.OpenAsync();
                return await sqlConnection.QueryAsync<Employee>(
                    "GetAllEmployee",
                    null,
                    commandType: CommandType.StoredProcedure);
            }

        }

        public async Task UpdateEmployee(Employee employee)
        {
            using (var sqlConnection = new SqlConnection(connectionstring))
            {
                await sqlConnection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@EmployeeID",employee.EmployeeId);
                parameters.Add("@FirstName", employee.FirstName);
                parameters.Add("@Surname", employee.Surname);

                await sqlConnection.ExecuteAsync(
                    "UpdateEmployee",
                    parameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task TermianteEmployee(int EmployeeID)
        {
            using (var sqlConnection = new SqlConnection(connectionstring))
            {
                await sqlConnection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@EmployeeID", EmployeeID);

                await sqlConnection.ExecuteAsync(
                    "DeleteEmployee",
                    parameters,
                    commandType: CommandType.StoredProcedure);
            }
        }

        public async Task InsertEmployee(Employee employee)
        {
            using (var sqlConnection = new SqlConnection(connectionstring))
            {
                await sqlConnection.OpenAsync();
                var parameters = new DynamicParameters();

                parameters.Add("@FirstName",employee.FirstName);
                parameters.Add("@Surname", employee.Surname);
                parameters.Add("@DateOfBirth",employee.DateOfBirth);
                parameters.Add("@GenderID",employee.FkGenderId);
                parameters.Add("@NationID",employee.FkNationId);

            }
        }

    }
}
