﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EmployeeDAL.Models
{
    public partial class Gender
    {
        public Gender()
        {
            Employees = new HashSet<Employee>();
            EmployeeModels = new HashSet<EmployeeModel>();
        }
        public int GenderId { get; set; }
        public string GenderType { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
        public virtual ICollection<EmployeeModel> EmployeeModels { get; set; }
    }
}
